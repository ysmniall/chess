# main file responsible for current game state and user input

import pygame as p
from chess import chessEngine

# UNIFIED VARS HERE !
WIDTH = HEIGHT = 512  # 400 MAY ALSO WORK
DIMENSION = 8
SQ_SIZE = HEIGHT // DIMENSION
MAX_FPS = 15

IMAGES = {}

'''
INITIALIZING OF IMAGES IS COST-EXPENSIVE MAX 1 TRY 
'''


def load_images():
    pieces = ['wp', 'bp', "bR", "bN", "bB", "bQ", "bK", "wR", "wN", "wB", "wQ", "wK"]
    for piece in pieces:
        IMAGES[piece] = p.transform.scale(p.image.load('images/' + piece + '.png'), (SQ_SIZE, SQ_SIZE))


'''
main driver code this will hande the user-input and updating the board graphics 
'''


def main():
    p.init()
    screen = p.display.set_mode((WIDTH, HEIGHT))
    clock = p.time.Clock()
    screen.fill(p.Color("white"))
    gs = chessEngine.GameState()
    load_images()  # only run once
    sq_selected = ()  # keep track of the last click of the user
    player_clicks = []  # keep track of player clicks ie: row 5 col 3 s

    running = True
    while running:
        for e in p.event.get():
            if e.type == p.QUIT:
                running = False
            elif e.type == p.MOUSEBUTTONDOWN:
                location = p.mouse.get_pos()  # x,y location of the mouse
                col = location[0] // SQ_SIZE
                row = location[1] // SQ_SIZE

                if sq_selected == (row, col):
                    sq_selected = ()
                    player_clicks = []
                else:
                    sq_selected = (row, col)
                    player_clicks.append(sq_selected)
                if len(player_clicks) == 2:
                    move = chessEngine.Move(player_clicks[0], player_clicks[1], gs.board)
                    print('-- ', move.getChessNotation())
                    print('-- turn white ', gs.whiteToMove)
                    gs.makeMove(move)
                    sq_selected = ()

        drawGameState(screen, gs)

        clock.tick(MAX_FPS)
        p.display.flip()


'''
responsible for all graphics 
order matters here 
first draw board then pieces 
top left square in always light 
'''

'''
draw squares on board like this 
'''


def drawGameState(screen, game_state):
    """
    Responsible for all the graphics within current game state.
    """
    drawBoard(screen)  # draw squares on the board
    drawPieces(screen, game_state.board)  # draw pieces on top of those squares


def drawBoard(screen):
    """
    Draw the squares on the board.
    The top left square is always light.
    """
    global colors
    colors = [p.Color("white"), p.Color("gray")]
    for row in range(DIMENSION):
        for column in range(DIMENSION):
            color = colors[((row + column) % 2)]
            p.draw.rect(screen, color, p.Rect(column * SQ_SIZE, row * SQ_SIZE, SQ_SIZE, SQ_SIZE))


'''
using current game STATE / draw pieces like this 
'''


def drawPieces(screen, board):
    pass
    for r in range(DIMENSION):
        for c in range(DIMENSION):
            piece = board[r][c]
            if piece != '--':
                # print('test')
                screen.blit(IMAGES[piece], p.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE))


if __name__ == '__main__':
    main()
